import streamlit as st
import pandas as pd
import numpy as np
from PIL import Image

## Text
st.title("용접기 AI 데이터셋")
st.write("용접공정에서 발생하는 4가지 데이터(용접 가압력, 전류, 전압, 통전시간)를 분석하여 불량품을 예측을 위한 데이터셋")
st.write(" ")

## Image upload
file = st.file_uploader("Choose a file", type=["pnp", "jpg", "gif"])

## Image
wf = Image.open('weld force.jfif')
wc = Image.open('weld current.png')
wv = Image.open('weld voltage.gif')
wt = Image.open('weld time.jpg')

## Radio button
selected_item = st.radio("사용된 변수 알아보기", ("weld force", "weld current", "weld voltage", "weld time"))
if selected_item == "weld force":
    st.image(wf)
    st.write("용접 가압력 : 용접 시에 받는 가압력의 합계")
elif selected_item == "weld current":
    st.image(wc)
    st.write("전류 : 단면을 통하여 단위 시간 당 흐르는 전하의 양")
elif selected_item == "weld voltage":
    st.image(wv)
    st.write("전압 : 일정한 전기장에서 단위 전하를 한 지점에서 다른 지점으로 이동하는 데 필요한 일")
elif selected_item == "weld time":
    st.image(wt)
    st.write("통전 시간 : 저항 용접에 있어서 용접 전류를 통과하는 시간")

## Dataframe upload
uploaded_file = st.file_uploader("Choose a file")
if uploaded_file is not None:
  df = pd.read_csv(uploaded_file)
  st.write(df)

## Data Frame(데이터 불러오기)
st.write("데이터 불러오기")
st.write(pd.DataFrame({
    'Machine_Name' : ['Spot-01', 'Spot-01', 'Spot-01', 'Spot-01', 'Spot-01'],
    'Item No' : [65235-25800, 65235-25800, 65235-25800, 65235-25800, 65235-25800],
    'working time' : ['2020-03-24', '2020-03-24', '2020-03-24', '2020-03-24', '2020-03-24'],
    'Thickness 1(mm)' : [0.7, 0.7, 0.7, 0.7, 0.7],
    'Thickness 2(mm)' : [0.7, 0.7, 0.7, 0.7, 0.7],
    'weld force(bar)' : [2.33, 2.36, 2.37, 2.37, 2.36],
    'weld current(kA)' : [14.57, 14.57, 14.57, 14.57, 14.56],
    'weld Voltage(v)' : [2.701, 2.701, 2.703, 2.703, 2.704],
    'weld time(ms)' : [72.0, 72.0, 71.0, 72.0, 72.0]
}))

## Data Frame(데이터 전처리)
st.write("데이터 전처리")
st.write(pd.DataFrame({
    'weld force(bar)' : [2.33, 2.36, 2.37, 2.37, 2.36],
    'weld current(kA)' : [14.57, 14.57, 14.57, 14.57, 14.56],
    'weld Voltage(v)' : [2.701, 2.701, 2.703, 2.703, 2.704],
    'weld time(ms)' : [72.0, 72.0, 71.0, 72.0, 72.0]
}))